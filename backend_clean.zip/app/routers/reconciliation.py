# app/routers/reconciliation.py
from fastapi import APIRouter, Depends, status
from sqlmodel import select
from typing import Annotated

# Core configuration, DB, roles, and auth dependencies
from app.core.database import SessionDep
from app.core.roles import require_management
from app.services.auth_service import get_current_active_user

# Models and Schemas
from app.models.transaction import Transaction
from app.models.payment import Payment
from app.models.user import User
from app.schemas.payment import PaymentStatus
from app.schemas.transaction import TransactionStatus

router = APIRouter(
    prefix="/reconciliation",
    tags=["Reconciliation"],
    dependencies=[Depends(require_management)]  # Restricts all routes in this file to Landlords & Caretakers
)

@router.post("/run")  
async def reconciliation(
    session: SessionDep,
    current_user: Annotated[User, Depends(require_management)]
):
    """
    Reconciles unverified payments against pending bank/M-Pesa transaction statements.
    This process is restricted to administrative roles (Landlord/Caretaker) and matches records
    via unique transaction references.
    """
    payments_query = select(Payment).where(Payment.status == PaymentStatus.UNVERIFIED)
    payments = session.exec(payments_query).all()
    
    txn_query = select(Transaction).where(Transaction.transaction_status == TransactionStatus.PENDING)
    txn = session.exec(txn_query).all()
    
    txn_map = {t.transaction_reference.strip().upper(): t for t in txn}
    matched_count = 0
    
    for payment in payments:
        if not payment.transaction_ref:
            continue
            
        ref_key = payment.transaction_ref.strip().upper()
        if ref_key in txn_map:
            matched_txn = txn_map[ref_key]
            payment.transaction_id = matched_txn.id
            
            # Adjust the enum attribute name here if your application models 
            # still contain the double 'I' typo (e.g., VERIFIIED vs VERIFIED)
            payment.status = getattr(PaymentStatus, "VERIFIED", getattr(PaymentStatus, "VERIFIIED", "VERIFIED"))
            matched_txn.transaction_status = TransactionStatus.MATCHED
            
            session.add(payment)
            session.add(matched_txn)
            
            matched_count += 1
            
    session.commit()
    
    return {
        "status": "success", 
        "matches_found": matched_count,
        "remaining_unverified": len(payments) - matched_count
    }