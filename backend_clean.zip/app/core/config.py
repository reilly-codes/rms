# app/core/config.py
import os
from dotenv import load_dotenv

load_dotenv()

class Settings:
    JWT_SECRET_KEY: str = os.getenv("JWT_SECRET_KEY", "your-fallback-super-secret-key-for-dev")
    ALGORITHM: str = "HS256"
    
    # Expirations (in minutes)
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 12   # 12 hours
    REFRESH_TOKEN_EXPIRE_MINUTES: int = 60 * 24  # 24 hours
    
    # Cookie Configurations
    ACCESS_COOKIE_NAME: str = "access_token"
    REFRESH_COOKIE_NAME: str = "refresh_token"
    COOKIE_SECURE: bool = os.getenv("ENVIRONMENT", "development") == "production"

settings = Settings()